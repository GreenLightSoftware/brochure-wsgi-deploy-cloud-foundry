# brochure-wsgi

Exposes the [brochure](https://github.com/GreenLightSoftware/brochure) python application to HTTP clients as a WSGI application.

## Run the local development server

`./scripts/run`

## Run the tests

`./scripts/test`

## Package source for distribution

`./scripts/sdist`
