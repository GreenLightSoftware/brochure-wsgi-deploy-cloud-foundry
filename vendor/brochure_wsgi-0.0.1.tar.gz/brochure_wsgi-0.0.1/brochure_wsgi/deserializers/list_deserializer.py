from typing import TypeVar, Callable, List, Generic

T = TypeVar('T')
U = TypeVar('U')


class ListDeserializer(Generic[T, U]):

    def __init__(self, detail_deserializer: Callable[[T], U]) -> None:
        self._detail_deserializer = detail_deserializer
        super().__init__()

    def __call__(self, items: List[T], *args, **kwargs) -> List[U]:
        return [self._detail_deserializer(item) for item in items if item is not None]
