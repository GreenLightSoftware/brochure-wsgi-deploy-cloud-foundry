from enum import Enum


class CommandType(Enum):
    UNKNOWN = 0
    SHOW_COVER = 1
