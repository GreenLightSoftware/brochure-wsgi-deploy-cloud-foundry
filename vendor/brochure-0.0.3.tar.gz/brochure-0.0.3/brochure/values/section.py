from typing import NamedTuple


class Section(NamedTuple):
    title: str
    body: str
