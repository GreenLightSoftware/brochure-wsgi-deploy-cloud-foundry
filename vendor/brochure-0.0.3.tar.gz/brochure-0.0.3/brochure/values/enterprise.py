from typing import NamedTuple


class Enterprise(NamedTuple):
    name: str
